import React, { useEffect, useMemo, useState } from "react";
import {
  ArrowUpRight, BookOpen, CalendarDays, Check, ChevronDown, CircleHelp,
  GraduationCap, Menu, Moon, Search, Settings2, Sun, Ticket, X,
  Accessibility, Type, Contrast, Eye, RotateCcw, Send, Sparkles, Bell,
  FileText, ShieldCheck, LogIn, UserPlus, LogOut, LayoutDashboard
} from "lucide-react";

const initialNotices = [
  { id: 1, title: "Sample Mathematics examination notice", category: "Exams", date: "Nov 03, 2026", version: 1, summary: "A fictional sample notice for the CampusMate demo. Confirm real dates with your college.", source: "Sample_Exam_Notice_v1.pdf", detail: "The sample Mathematics exam is shown as 08 December 2026 at 10:00 AM in Room 204. This is fictional demo data." },
  { id: 2, title: "Admissions document checklist", category: "Admissions", date: "Oct 28, 2026", version: 1, summary: "A sample checklist showing how an admission notice could be displayed.", source: "Sample_Admissions_Checklist.pdf", detail: "Bring the documents listed in your official admission notice. Requirements vary by programme." },
  { id: 3, title: "Fee payment information", category: "Fees", date: "Oct 22, 2026", version: 1, summary: "A sample fee notice. Check the official college portal for actual deadlines.", source: "Sample_Fee_Notice.pdf", detail: "This fictional notice demonstrates how fee information and its source can be shown." },
  { id: 4, title: "Weekly timetable sample", category: "Timetables", date: "Oct 18, 2026", version: 1, summary: "A demo timetable notice with no real class schedule.", source: "Sample_Timetable.pdf", detail: "Please refer to your official class timetable for accurate room and time information." },
  { id: 5, title: "Campus activity registration", category: "Activities", date: "Oct 12, 2026", version: 1, summary: "A fictional event notice for demonstrating the noticeboard.", source: "Sample_Activity_Notice.pdf", detail: "This is only a demo. Event dates, eligibility, and registration links must be confirmed by the college." }
];

const categories = ["All notices", "Admissions", "Fees", "Exams", "Timetables", "Activities"];
const sampleAnswer = (question, notice) => {
  if (!question.trim()) return null;
  const q = question.toLowerCase();
  if (q.includes("exam") || q.includes("mathematics") || q.includes("math")) {
    return {
      answer: notice?.detail || "I found a fictional sample exam notice. Please confirm the actual date with your college.",
      source: notice?.source || "Sample_Exam_Notice_v1.pdf",
      date: notice?.date || "Nov 03, 2026",
      version: notice?.version || 1
    };
  }
  if (q.includes("admission")) return { answer: initialNotices[1].detail, source: initialNotices[1].source, date: initialNotices[1].date, version: 1 };
  if (q.includes("fee")) return { answer: initialNotices[2].detail, source: initialNotices[2].source, date: initialNotices[2].date, version: 1 };
  if (q.includes("timetable") || q.includes("class")) return { answer: initialNotices[3].detail, source: initialNotices[3].source, date: initialNotices[3].date, version: 1 };
  return { answer: "I can’t verify that from the sample notices yet. Try adding your programme and semester, or save this question as a helpdesk ticket for follow-up.", source: null, date: null, version: null };
};

function App() {
  const [theme, setTheme] = useState(localStorage.getItem("cm-theme") || "dark");
  const [largeText, setLargeText] = useState(localStorage.getItem("cm-large") === "true");
  const [highContrast, setHighContrast] = useState(localStorage.getItem("cm-contrast") === "true");
  const [reduceMotion, setReduceMotion] = useState(localStorage.getItem("cm-motion") === "true");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [page, setPage] = useState("home");
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("cm-user") || "null"));
  const [authMode, setAuthMode] = useState("login");
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [question, setQuestion] = useState("");
  const [programme, setProgramme] = useState("");
  const [semester, setSemester] = useState("");
  const [chatAnswer, setChatAnswer] = useState(null);
  const [notices, setNotices] = useState(() => JSON.parse(localStorage.getItem("cm-notices") || "null") || initialNotices);
  const [noticeSearch, setNoticeSearch] = useState("");
  const [noticeCategory, setNoticeCategory] = useState("All notices");
  const [tickets, setTickets] = useState(() => JSON.parse(localStorage.getItem("cm-tickets") || "[]"));
  const [ticketTitle, setTicketTitle] = useState("");
  const [ticketTopic, setTicketTopic] = useState("General");
  const [ticketDetails, setTicketDetails] = useState("");
  const [adminOpen, setAdminOpen] = useState(false);
  const [adminTitle, setAdminTitle] = useState("Mathematics examination notice — replacement");
  const [noticeUpdated, setNoticeUpdated] = useState(false);

  useEffect(() => {
    localStorage.setItem("cm-theme", theme);
    document.documentElement.dataset.theme = theme;
  }, [theme]);
  useEffect(() => {
    localStorage.setItem("cm-large", largeText);
    document.documentElement.classList.toggle("large-text", largeText);
  }, [largeText]);
  useEffect(() => {
    localStorage.setItem("cm-contrast", highContrast);
    document.documentElement.classList.toggle("high-contrast", highContrast);
  }, [highContrast]);
  useEffect(() => {
    localStorage.setItem("cm-motion", reduceMotion);
    document.documentElement.classList.toggle("reduce-motion", reduceMotion);
  }, [reduceMotion]);
  useEffect(() => localStorage.setItem("cm-notices", JSON.stringify(notices)), [notices]);
  useEffect(() => localStorage.setItem("cm-tickets", JSON.stringify(tickets)), [tickets]);

  const filteredNotices = useMemo(() => notices.filter(n =>
    (noticeCategory === "All notices" || n.category === noticeCategory) &&
    `${n.title} ${n.category} ${n.summary}`.toLowerCase().includes(noticeSearch.toLowerCase())
  ), [notices, noticeCategory, noticeSearch]);

  function navigate(next) {
    setPage(next);
    setMobileMenu(false);
    setSettingsOpen(false);
    window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
  }
  function submitAuth(e) {
    e.preventDefault();
    setAuthError("");
    if (!authEmail.trim() || !authPassword.trim()) return setAuthError("Please enter your email and password.");
    if (authMode === "signup" && !authName.trim()) return setAuthError("Please enter your name.");
    const nextUser = { name: authMode === "signup" ? authName.trim() : (authEmail.split("@")[0] || "Student"), email: authEmail.trim() };
    localStorage.setItem("cm-user", JSON.stringify(nextUser));
    setUser(nextUser);
    navigate("dashboard");
  }
  function logout() {
    localStorage.removeItem("cm-user");
    setUser(null);
    navigate("home");
  }
  function askCampusMate(e) {
    e?.preventDefault();
    const answer = sampleAnswer(question, notices.find(n => n.category === "Exams"));
    setChatAnswer(answer);
  }
  function saveTicket(e) {
    e.preventDefault();
    if (!ticketTitle.trim()) return;
    const ticket = { id: Date.now(), title: ticketTitle.trim(), topic: ticketTopic, details: ticketDetails.trim(), status: "Open", created: new Date().toLocaleDateString() };
    setTickets([ticket, ...tickets]);
    setTicketTitle(""); setTicketDetails("");
    alert("Demo ticket saved in this browser. It has not been sent to college staff.");
  }
  function publishDemoNotice() {
    const next = notices.map(n => n.category === "Exams" ? { ...n, title: adminTitle || n.title, detail: "The replacement sample exam is shown as 10 December 2026 at 10:00 AM in Room 204. This is fictional demo data.", date: "Nov 08, 2026", version: n.version + 1, source: "Sample_Exam_Notice_v2.pdf" } : n);
    setNotices(next);
    setNoticeUpdated(true);
    setAdminOpen(false);
    setChatAnswer(null);
  }

  const NavLink = ({ target, children }) => <button className={`nav-link ${page === target ? "active" : ""}`} onClick={() => navigate(target)}>{children}</button>;

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => navigate("home")} aria-label="CampusMate home">
          <span className="brand-mark"><GraduationCap size={21}/></span>
          <span>campusmate<span className="brand-dot">.</span><small>STUDENT HELP DESK</small></span>
        </button>
        <nav className={`nav ${mobileMenu ? "open" : ""}`}>
          <NavLink target="home">Overview</NavLink>
          <NavLink target="helpdesk">Ask CampusMate</NavLink>
          <NavLink target="notices">Noticeboard</NavLink>
          <NavLink target="tickets">Helpdesk tickets</NavLink>
        </nav>
        <div className="top-actions">
          <button className="icon-btn" aria-label="Accessibility and appearance settings" onClick={() => setSettingsOpen(!settingsOpen)}><Accessibility size={19}/></button>
          {user ? <button className="user-chip" onClick={() => navigate("dashboard")}><span className="avatar">{user.name?.[0]?.toUpperCase() || "S"}</span><span className="user-name">{user.name}</span></button> : <button className="btn btn-small btn-outline" onClick={() => {setAuthMode("login"); navigate("auth");}}>Log in</button>}
          <button className="btn btn-small btn-primary desktop-signup" onClick={() => {setAuthMode("signup"); navigate("auth");}}>Get started <ArrowUpRight size={15}/></button>
          <button className="icon-btn mobile-menu-btn" aria-label="Open navigation" onClick={() => setMobileMenu(!mobileMenu)}>{mobileMenu ? <X size={20}/> : <Menu size={20}/>}</button>
        </div>
        {settingsOpen && <div className="settings-popover">
          <div className="popover-head"><strong>Appearance & accessibility</strong><button className="icon-btn tiny" onClick={() => setSettingsOpen(false)} aria-label="Close settings"><X size={15}/></button></div>
          <div className="setting-row"><span><Sun size={16}/> Light theme</span><button className={`switch ${theme === "light" ? "on" : ""}`} role="switch" aria-checked={theme === "light"} onClick={() => setTheme(theme === "light" ? "dark" : "light")}><i/></button></div>
          <div className="setting-row"><span><Type size={16}/> Larger text</span><button className={`switch ${largeText ? "on" : ""}`} role="switch" aria-checked={largeText} onClick={() => setLargeText(!largeText)}><i/></button></div>
          <div className="setting-row"><span><Contrast size={16}/> High contrast</span><button className={`switch ${highContrast ? "on" : ""}`} role="switch" aria-checked={highContrast} onClick={() => setHighContrast(!highContrast)}><i/></button></div>
          <div className="setting-row"><span><Eye size={16}/> Reduce animations</span><button className={`switch ${reduceMotion ? "on" : ""}`} role="switch" aria-checked={reduceMotion} onClick={() => setReduceMotion(!reduceMotion)}><i/></button></div>
          <p className="tiny-note">Settings are saved in this browser.</p>
        </div>}
      </header>

      {page === "home" && <>
        <main>
          <section className="hero section-wrap">
            <div className="hero-copy">
              <div className="eyebrow"><span className="sparkle">✦</span> THE STUDENT SPACE <span className="eyebrow-line"/></div>
              <h1>A little more<br/><span className="gradient-text">“where do I find…?”</span></h1>
              <p className="hero-sub">Good answers come with something you can check. Meet your campus companion for admissions, fees, exams, timetables and campus life.</p>
              <div className="hero-buttons">
                <button className="btn btn-primary btn-large" onClick={() => navigate("helpdesk")}>Meet your helpdesk <ArrowUpRight size={17}/></button>
                <button className="btn btn-ghost btn-large" onClick={() => navigate("notices")}>Explore notices <ArrowUpRight size={17}/></button>
              </div>
              <div className="hero-note"><span className="pulse-dot"/> 3D motion on <span className="note-divider"/> Made for student life</div>
            </div>
            <div className="hero-art">
              <div className="orb orb-one"/><div className="orb orb-two"/>
              <div className="mascot-card">
                <div className="mascot-label"><span className="status-dot"/> CAMPUSMATE AI <span>CM — 01</span></div>
                <div className="mascot">
                  <div className="mascot-halo"/>
                  <div className="mascot-head"><div className="ear ear-left"/><div className="ear ear-right"/><div className="face"><div className="eye eye-left"/><div className="eye eye-right"/><div className="cheek cheek-left"/><div className="cheek cheek-right"/><div className="mouth"/></div><div className="head-gloss"/></div>
                  <div className="mascot-body"><div className="body-light"/><div className="badge-star">✦</div></div>
                  <div className="mascot-shadow"/>
                </div>
                <div className="mascot-caption"><span>✦</span><div><b>Hey! Ask me anything.</b><small>Always with a source</small></div><span className="caption-arrow">↗</span></div>
              </div>
              <div className="floating-note note-source"><FileText size={15}/><span><b>Source attached</b><small>Every answer, traceable</small></span><Check size={15}/></div>
              <div className="floating-note note-chat"><Sparkles size={16}/><span><b>Campus questions.</b><small>Clear answers.</small></span></div>
            </div>
          </section>

          <section className="section-wrap intro-strip">
            <div><span className="eyebrow">A LITTLE LESS “WHERE DO I FIND…?”</span><h2>Hey there, campus explorer<span className="gradient-text">.</span></h2></div>
            <p>From your first admission form to your next exam. Find the answer, and the official notice behind it.</p>
            <button className="round-arrow" onClick={() => navigate("helpdesk")} aria-label="Go to helpdesk"><ArrowUpRight size={20}/></button>
          </section>

          <section className="section-wrap topic-section">
            <div className="section-heading"><div><span className="eyebrow">✦ MEET YOUR CAMPUS COMPANION</span><h2>Campus questions.<br/><span className="muted-heading">Clear answers.</span></h2></div><p>Start with a topic, or just ask.</p></div>
            <div className="topic-grid">
              {[
                ["Admissions","Start your journey","admissions",GraduationCap],
                ["Fees & payments","Stay on track","fees",BookOpen],
                ["Examinations","Plan your prep","exam",CalendarDays],
                ["Timetables","Know what’s next","timetable",Bell],
                ["Campus life","Get involved","activities",Sparkles]
              ].map(([title,desc,topic,Icon],i)=><button className={`topic-card topic-${i}`} key={title} onClick={()=>{setQuestion(`Tell me about ${title.toLowerCase()}`);navigate("helpdesk");}}>
                <span className="topic-icon"><Icon size={20}/></span><span className="topic-number">0{i+1}</span><b>{title}</b><small>{desc}</small><ArrowUpRight className="topic-arrow" size={17}/>
              </button>)}
            </div>
          </section>

          <section className="section-wrap notice-preview">
            <div className="notice-preview-copy"><span className="eyebrow">ONE PLACE FOR THE DETAILS</span><h2>The<br/><span className="gradient-text">noticeboard.</span></h2><p>Find a notice. Open the source. Get the full picture.</p><button className="btn btn-outline" onClick={() => navigate("notices")}>Browse notices <ArrowUpRight size={16}/></button></div>
            <div className="notice-stack">
              {notices.slice(0,3).map((n,i)=><div className={`notice-mini mini-${i}`} key={n.id}><div className="notice-mini-icon"><FileText size={17}/></div><div><span className="notice-category">{n.category} · SAMPLE</span><b>{n.title}</b><small>{n.date} · Version {n.version}</small></div><ArrowUpRight size={16}/></div>)}
              <div className="notice-watermark">CAMPUS<br/>EDIT <span>✦</span></div>
            </div>
          </section>

          <section className="section-wrap trust-section">
            <div className="section-heading"><div><span className="eyebrow">A HELPDESK YOU CAN CHECK</span><h2>A clear answer.<br/><span className="muted-heading">An actual source.</span></h2></div><p>CampusMate brings the right information closer to the student.</p></div>
            <div className="trust-grid">
              <div><span className="trust-num">01 / ASK</span><h3>Use your own words.</h3><p>Ask about admissions, fees, exams, timetables or activities. Add programme and semester for context.</p></div>
              <div><span className="trust-num">02 / CHECK</span><h3>See where it came from.</h3><p>Open the source notice, publication date and version. No mystery answers.</p></div>
              <div><span className="trust-num">03 / KEEP GOING</span><h3>Know the next step.</h3><p>When a source is missing, save a demo ticket instead of relying on a guess.</p></div>
            </div>
          </section>
          <section className="section-wrap update-banner"><div><span className="eyebrow">TRY THE PRESENTATION, FOR REAL</span><h2>A notice changes.<br/><span className="gradient-text">The answer changes with it.</span></h2><p>Explore the demo admin panel and publish a replacement sample notice.</p></div><button className="btn btn-primary" onClick={()=>setAdminOpen(true)}>Try a notice update <ArrowUpRight size={16}/></button></section>
        </main>
      </>}

      {page === "auth" && <main className="auth-page section-wrap">
        <div className="auth-art"><div className="auth-orb"/><div className="auth-mini-mascot"><div className="mini-face"><i/><i/><b/></div></div><span className="eyebrow">YOUR CAMPUS COMPANION</span><h2>A little clarity<br/>goes a long way.</h2><p>Ask a question. Find the source. Keep moving.</p></div>
        <div className="auth-card">
          <button className="back-link" onClick={()=>navigate("home")}>← Back to home</button>
          <div className="auth-tabs"><button className={authMode==="login"?"selected":""} onClick={()=>{setAuthMode("login");setAuthError("");}}>Log in</button><button className={authMode==="signup"?"selected":""} onClick={()=>{setAuthMode("signup");setAuthError("");}}>Create account</button></div>
          <h1>{authMode==="login"?"Welcome back.":"Join CampusMate."}</h1><p className="auth-sub">{authMode==="login"?"Pick up where you left off.":"A clearer campus experience starts here."}</p>
          <form onSubmit={submitAuth}>
            {authMode==="signup" && <label>Your name<input value={authName} onChange={e=>setAuthName(e.target.value)} placeholder="Student name" autoComplete="name"/></label>}
            <label>Email address<input type="email" value={authEmail} onChange={e=>setAuthEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" required/></label>
            <label>Password<input type="password" value={authPassword} onChange={e=>setAuthPassword(e.target.value)} placeholder="Enter password" autoComplete={authMode==="login"?"current-password":"new-password"} required/></label>
            {authError && <p className="form-error" role="alert">{authError}</p>}
            <button className="btn btn-primary btn-full" type="submit">{authMode==="login"?"Log in":"Create demo account"} <ArrowUpRight size={16}/></button>
          </form>
          <p className="demo-warning"><ShieldCheck size={15}/> Demo-only authentication. Connect Firebase Authentication before production.</p>
        </div>
      </main>}

      {page === "dashboard" && <main className="section-wrap page-content"><div className="page-kicker"><LayoutDashboard size={16}/> STUDENT SPACE</div><h1>Welcome back, <span className="gradient-text">{user?.name || "student"}.</span></h1><p className="page-lead">Your campus companion is ready when you are.</p><div className="dashboard-grid"><button className="dashboard-tile" onClick={()=>navigate("helpdesk")}><CircleHelp/><b>Ask CampusMate</b><small>Find an answer with a source</small><ArrowUpRight/></button><button className="dashboard-tile" onClick={()=>navigate("notices")}><FileText/><b>Browse notices</b><small>Explore campus information</small><ArrowUpRight/></button><button className="dashboard-tile" onClick={()=>navigate("tickets")}><Ticket/><b>My tickets</b><small>{tickets.length} saved demo ticket(s)</small><ArrowUpRight/></button></div><button className="btn btn-outline" onClick={logout}><LogOut size={16}/> Log out</button></main>}

      {page === "helpdesk" && <main className="section-wrap page-content"><div className="page-kicker"><Sparkles size={16}/> YOUR CAMPUS COMPANION</div><h1>What’s on your <span className="gradient-text">mind?</span></h1><p className="page-lead">Ask a campus question. We’ll look for a matching sample notice.</p><div className="chat-layout"><div className="chat-panel"><div className="chat-top"><div className="bot-avatar">✦</div><div><b>CampusMate</b><small><span className="status-dot"/> Demo knowledge desk</small></div><span className="demo-tag">SAMPLE MODE</span></div><div className="chat-body"><div className="message bot-message">Hey there! Ask about admissions, fees, examinations, timetables or campus activities. Add your programme and semester for better context.</div>{chatAnswer && <><div className="message user-message">{question}</div><div className="message bot-message"><p>{chatAnswer.answer}</p>{chatAnswer.source && <div className="source-card"><FileText size={17}/><div><b>{chatAnswer.source}</b><small>{chatAnswer.date} · Version {chatAnswer.version}</small></div><span className="source-check"><Check size={14}/></span></div>}<small className="demo-disclaimer">Fictional sample answer. Confirm details with official college sources.</small></div></>}</div><form className="chat-form" onSubmit={askCampusMate}><div className="context-fields"><label>Programme <input value={programme} onChange={e=>setProgramme(e.target.value)} placeholder="e.g. BSc CS"/></label><label>Semester <select value={semester} onChange={e=>setSemester(e.target.value)}><option value="">Select</option>{[1,2,3,4,5,6,7,8].map(s=><option key={s}>{s}</option>)}</select></label></div><div className="chat-input-row"><input value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Ask a campus question…" aria-label="Ask a campus question"/><button className="send-btn" type="submit" aria-label="Send question"><Send size={18}/></button></div><div className="quick-prompts">{["When is my exam?","Admission checklist","Fee information"].map(q=><button type="button" onClick={()=>setQuestion(q)} key={q}>{q} ↗</button>)}</div></form></div><aside className="chat-side"><span className="eyebrow">ASK ABOUT</span>{["Admissions","Fees & payments","Examinations","Timetables","Campus activities"].map((x,i)=><button key={x} onClick={()=>setQuestion(`Tell me about ${x.toLowerCase()}`)}><span>0{i+1}</span>{x}<ArrowUpRight size={15}/></button>)}<p>Answers in this preview use fictional notices and local demo logic. No AI service is connected yet.</p></aside></div></main>}

      {page === "notices" && <main className="section-wrap page-content"><div className="page-kicker"><BookOpen size={16}/> THE CAMPUS EDIT</div><h1>Good to <span className="gradient-text">know.</span></h1><p className="page-lead">Find a notice. Open the source. Get the full picture.</p><div className="notice-toolbar"><div className="search-box"><Search size={17}/><input value={noticeSearch} onChange={e=>setNoticeSearch(e.target.value)} placeholder="Search a title, topic or keyword…"/></div><div className="filter-pills">{categories.map(c=><button className={noticeCategory===c?"selected":""} key={c} onClick={()=>setNoticeCategory(c)}>{c}</button>)}</div></div><div className="notice-grid">{filteredNotices.map(n=><article className="notice-card" key={n.id}><div className="notice-card-top"><span className="notice-category">{n.category.toUpperCase()}</span><span className="notice-version">V{n.version}</span></div><div className="notice-document"><FileText size={28}/><span>CM / NOTICE</span></div><h3>{n.title}</h3><p>{n.summary}</p><div className="notice-card-footer"><span>{n.date}</span><button onClick={()=>alert(`${n.source}\\n\\n${n.detail}\\n\\nFictional demo notice — not an official college document.`)}>View source <ArrowUpRight size={15}/></button></div></article>)}</div>{filteredNotices.length===0 && <div className="empty-state">No notices match that search. Try another keyword.</div>}<p className="demo-disclaimer notice-disclaimer">All notices are fictional examples for this prototype. Replace them with college-approved documents before real use.</p></main>}

      {page === "tickets" && <main className="section-wrap page-content"><div className="page-kicker"><Ticket size={16}/> WHEN A NOTICE ISN’T ENOUGH</div><h1>A clear <span className="gradient-text">next step.</span></h1><p className="page-lead">Save a question that needs a more personal answer.</p><div className="ticket-layout"><form className="ticket-form" onSubmit={saveTicket}><h2>New ticket</h2><label>Short title<input value={ticketTitle} onChange={e=>setTicketTitle(e.target.value)} placeholder="What do you need help with?" required/></label><label>Topic<select value={ticketTopic} onChange={e=>setTicketTopic(e.target.value)}>{categories.slice(1).map(c=><option key={c}>{c}</option>)}<option>General</option></select></label><label>Details<textarea value={ticketDetails} onChange={e=>setTicketDetails(e.target.value)} placeholder="Add a few details…" rows={4}/></label><button className="btn btn-primary" type="submit">Save demo ticket <ArrowUpRight size={16}/></button><small className="demo-disclaimer">Saved only in this browser. It is not sent to college staff.</small></form><div className="ticket-list"><div className="ticket-list-head"><h2>Your tickets</h2><span>{tickets.length} open</span></div>{tickets.length===0?<div className="empty-state"><Ticket size={28}/><b>No tickets yet</b><span>Your saved questions will appear here.</span></div>:tickets.map(t=><div className="ticket-item" key={t.id}><span className="ticket-icon"><Ticket size={17}/></span><div><b>{t.title}</b><small>{t.topic} · {t.created}</small><p>{t.details || "No extra details provided."}</p></div><span className="ticket-status">{t.status}</span></div>)}</div></div></main>}

      <footer className="footer"><div className="footer-brand"><span className="brand-mark"><GraduationCap size={20}/></span><div><b>campusmate<span className="brand-dot">.</span></b><small>A little clarity for campus life.</small></div></div><div className="footer-links"><button onClick={()=>navigate("home")}>Overview</button><button onClick={()=>navigate("helpdesk")}>Ask CampusMate</button><button onClick={()=>navigate("notices")}>Noticeboard</button><button onClick={()=>navigate("tickets")}>Helpdesk tickets</button></div><div className="footer-bottom"><span>SRUJAN 2026 · STUDENT HELPDESK DEMO</span><span>Demo only · Fictional sample data</span></div></footer>

      {adminOpen && <div className="modal-backdrop" role="presentation" onClick={()=>setAdminOpen(false)}><div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="admin-title" onClick={e=>e.stopPropagation()}><button className="modal-close icon-btn" onClick={()=>setAdminOpen(false)} aria-label="Close"><X size={18}/></button><div className="page-kicker"><Settings2 size={16}/> DEMO KNOWLEDGE DESK</div><h2 id="admin-title">Keep the answer current.</h2><p>Publish a replacement sample exam notice. This updates local demo data only.</p><label>Notice title<input value={adminTitle} onChange={e=>setAdminTitle(e.target.value)}/></label><div className="update-compare"><div><small>BEFORE</small><b>08 DEC</b><span>Version 1 · superseded</span></div><ArrowUpRight/><div><small>AFTER</small><b>10 DEC</b><span>Version 2 · replacement</span></div></div><button className="btn btn-primary btn-full" onClick={publishDemoNotice}>Publish demo update <ArrowUpRight size={16}/></button><small className="demo-disclaimer">No real notice is published. This is a local prototype interaction.</small></div></div>}
      {noticeUpdated && <div className="toast"><Check size={16}/> Sample notice updated to Version 2 <button onClick={()=>setNoticeUpdated(false)} aria-label="Dismiss"><X size={14}/></button></div>}
    </div>
  );
}

export default App;
